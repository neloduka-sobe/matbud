<?php

defined( '_VALID_MOS' ) or die( 'Verbotener, direkter Zugriff auf diesen Bereich.' );

global $mosConfig_live_site;

echo "<script type=\"text/javascript\" src=\"".$mosConfig_live_site."/modules/mod_mistelzweig_js.php\"></script>";

?>
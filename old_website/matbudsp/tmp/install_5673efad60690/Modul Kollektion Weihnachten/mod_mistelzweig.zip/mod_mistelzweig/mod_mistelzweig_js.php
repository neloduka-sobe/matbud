<?php
	
	header("Cache-Control: must-revalidate");
	$offset = 60*60*24*60;
	$ExpStr = "Expires: ".gmdate("D, d M Y H:i:s",time() + $offset)." GMT";
	header($ExpStr);
	header('Content-Type: application/x-javascript');

	global $mosConfig_live_site;
?>

//Javasript by Mario Boro (c) 2006-2007

var no = 15; // Anzahl der Objekte
var speed = 20; // Speed der Objekte
var mistelzweig = "modules/mod_mistelzweig.gif"; // Pfad zum Bild
var ns4up = (navigator.appName=="Netscape" && navigator.appVersion.charAt(0)=="4") ? 1 : 0;
var ie4up = (document.all) ? 1 : 0;
var ns6up = (document.getElementById&&!document.all) ? 1 : 0;
var dx, xp, yp; 
var am, stx, sty; 
var i, doc_width = 800, doc_height = 100;
if (ns4up||ns6up) { 
doc_width = self.innerWidth;
doc_height = self.innerHeight;
} else if (ie4up) {
doc_width = document.body.clientWidth;
doc_height = document.body.clientHeight;
}
dx = new Array();
xp = new Array();
yp = new Array();
am = new Array();
stx = new Array();
sty = new Array();
for (i = 0; i < no; ++ i) {
dx[i] = 0; // Koordinaten-Variable setzen
xp[i] = Math.random()*(doc_width-50); // Position-Variable setzen
yp[i] = Math.random()*doc_height;
am[i] = Math.random()*20; // Amplituden-Variable setzten
stx[i] = 0.02 + Math.random()/10; // Variable f�r Schrittweite setzen
sty[i] = 0.7 + Math.random(); // Variable f�r Schrittweite setzen

// Layer konfigurieren f�r Netscape
if (ns4up) {
if (i == 0) {
document.write("<layer name=\"dot"+ i +"\" left=\"15\" ");
document.write("top=\"15\" visibility=\"show\"><img src=\"");
document.write(mistelzweig + "\" border=\"0\"></layer>");
} else {
document.write("<layer name=\"dot"+ i +"\" left=\"15\" ");
document.write("top=\"15\" visibility=\"show\"><img src=\"");
document.write(mistelzweig + "\" border=\"0\"></layer>");
}

// Layer konfigurieren f�r NS4
} else if (ie4up||ns6up) {
if (i == 0) {
document.write("<div id=\"dot"+ i +"\" style=\"POSITION: ");
document.write("absolute; Z-INDEX: "+ i +"; VISIBILITY: ");
document.write("visible; TOP: 15px; LEFT: 15px;\"><img src=\"");
document.write(mistelzweig + "\" border=\"0\"></div>");
} else {
document.write("<div id=\"dot"+ i +"\" style=\"POSITION: ");
document.write("absolute; Z-INDEX: "+ i +"; VISIBILITY: ");
document.write("visible; TOP: 15px; LEFT: 15px;\"><img src=\"");
document.write(mistelzweig + "\" border=\"0\"></div>");
}
}
}

// Haupt-Animations-Funktion f�r Netscape
function mistelzweigNS() {
for (i = 0; i < no; ++ i) {
yp[i] += sty[i];
if (yp[i] > doc_height-50) {
xp[i] = Math.random()*(doc_width-am[i]-30);
yp[i] = 0;
stx[i] = 0.02 + Math.random()/10;
sty[i] = 0.7 + Math.random();
doc_width = self.innerWidth;
doc_height = self.innerHeight;
}
dx[i] += stx[i];
document.layers["dot"+i].top = yp[i];
document.layers["dot"+i].left = xp[i] + am[i]*Math.sin(dx[i]);
}
setTimeout("mistelzweigNS()", speed);
}

// Haupt-Animations-Funktion f�r Internet Explorer
function mistelzweigIE() {
for (i = 0; i < no; ++ i) {
yp[i] += sty[i];
if (yp[i] > doc_height-50) {
xp[i] = Math.random()*(doc_width-am[i]-30);
yp[i] = 0;
stx[i] = 0.02 + Math.random()/10;
sty[i] = 0.7 + Math.random();
doc_width = document.body.clientWidth;
doc_height = document.body.clientHeight;
}
dx[i] += stx[i];
document.all["dot"+i].style.pixelTop = yp[i];
document.all["dot"+i].style.pixelLeft = xp[i] + am[i]*Math.sin(dx[i]);
}
setTimeout("mistelzweigIE()", speed);
}
// Haupt-Animations-Funktion f�r Netscape6 und Mozilla
function mistelzweigNS6() {
for (i = 0; i < no; ++ i) {
yp[i] += sty[i];
if (yp[i] > doc_height-50) {
xp[i] = Math.random()*(doc_width-am[i]-30);
yp[i] = 0;
stx[i] = 0.02 + Math.random()/10;
sty[i] = 0.7 + Math.random();
doc_width = self.innerWidth;
doc_height = self.innerHeight;
}
dx[i] += stx[i];
document.getElementById("dot"+i).style.top = yp[i]+"px";
document.getElementById("dot"+i).style.left = xp[i] + am[i]*Math.sin(dx[i])+"px";
}
setTimeout("mistelzweigNS6()", speed);
}
if (ns4up) {
mistelzweigNS();
} else if (ie4up) {
mistelzweigIE();
}else if (ns6up) {
mistelzweigNS6();
}